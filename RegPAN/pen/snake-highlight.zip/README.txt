A Pen created at CodePen.io. You can find this one at https://codepen.io/anukkrit149/pen/jXQNyJ.

 Slithering highlight in login form